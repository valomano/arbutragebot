const socket = new WebSocket("ws://127.0.0.1:8080/ws/arbitrage");

socket.onmessage = function(event) {
    const data = JSON.parse(event.data);
    const tableBody = document.getElementById("arbitrage-table-body");
    tableBody.innerHTML = "";  // 🗑 Очищаем старые данные

    data.forEach(signal => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${signal.asset}</td>
            <td>${signal.buy_exchange} @ ${signal.buy_price}</td>
            <td>${signal.sell_exchange} @ ${signal.sell_price}</td>
            <td>${signal.spread}%</td>
            <td>${signal.type}</td>
        `;

        tableBody.appendChild(row);
    });
};

socket.onopen = function() {
    console.log("✅ WebSocket подключен!");
};

socket.onerror = function(error) {
    console.error("❌ Ошибка WebSocket:", error);
};
