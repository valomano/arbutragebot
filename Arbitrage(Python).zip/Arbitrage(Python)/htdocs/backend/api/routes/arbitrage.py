from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database.db_connector import get_db
from backend.core.arbitrage import find_arbitrage_opportunities

router = APIRouter()

@router.get("/arbitrage")
def get_arbitrage_opportunities(db: Session = Depends(get_db)):
    """🔍 Возвращает список арбитражных возможностей."""
    signals = find_arbitrage_opportunities(db)
    return {"arbitrage_signals": [signal.to_dict() for signal in signals]}
